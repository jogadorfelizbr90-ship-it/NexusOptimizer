using Microsoft.Win32;
using System.Diagnostics;
using System.Net.NetworkInformation;
using System.Runtime.InteropServices;
using System.Text;

namespace NexusOptimizer;

public sealed class MainForm : Form
{
    private readonly Color bg = Color.FromArgb(13, 17, 28);
    private readonly Color panel = Color.FromArgb(22, 29, 45);
    private readonly Color accent = Color.FromArgb(94, 120, 255);
    private readonly Panel content = new() { Dock = DockStyle.Fill, Padding = new Padding(26), AutoScroll = true };
    private readonly Label pageTitle = new() { AutoSize = true, ForeColor = Color.White, Font = new Font("Segoe UI", 22, FontStyle.Bold) };
    private readonly Label status = new() { AutoSize = true, ForeColor = Color.FromArgb(155, 170, 194), Font = new Font("Segoe UI", 9) };
    private readonly ListBox output = new() { Dock = DockStyle.Fill, BackColor = Color.FromArgb(15, 21, 34), ForeColor = Color.Gainsboro, BorderStyle = BorderStyle.None, Font = new Font("Consolas", 10), HorizontalScrollbar = true };

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
    private class MEMORYSTATUSEX
    {
        public uint dwLength = (uint)Marshal.SizeOf(typeof(MEMORYSTATUSEX));
        public uint dwMemoryLoad; public ulong ullTotalPhys; public ulong ullAvailPhys;
        public ulong ullTotalPageFile; public ulong ullAvailPageFile; public ulong ullTotalVirtual;
        public ulong ullAvailVirtual; public ulong ullAvailExtendedVirtual;
    }
    [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)] private static extern bool GlobalMemoryStatusEx([In, Out] MEMORYSTATUSEX lpBuffer);

    public MainForm()
    {
        Text = "NEXUS OPTIMIZER"; Width = 1180; Height = 760; MinimumSize = new Size(980, 650);
        BackColor = bg; ForeColor = Color.White; Font = new Font("Segoe UI", 10); StartPosition = FormStartPosition.CenterScreen;
        var shell = new Panel { Dock = DockStyle.Fill, BackColor = bg }; Controls.Add(shell);
        var sidebar = new Panel { Dock = DockStyle.Left, Width = 225, BackColor = Color.FromArgb(17, 23, 37), Padding = new Padding(16) }; shell.Controls.Add(sidebar);
        var brand = new Label { Text = "NEXUS\nOPTIMIZER", Dock = DockStyle.Top, Height = 92, ForeColor = Color.White, Font = new Font("Segoe UI", 19, FontStyle.Bold) }; sidebar.Controls.Add(brand);
        var nav = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.TopDown, WrapContents = false, AutoScroll = true, Padding = new Padding(0, 12, 0, 0), BackColor = sidebar.BackColor }; sidebar.Controls.Add(nav);
        AddNav(nav, "⌂   Visão geral", ShowDashboard);
        AddNav(nav, "◈   Desempenho", ShowPerformance);
        AddNav(nav, "▤   Limpeza segura", ShowCleaner);
        AddNav(nav, "◷   Inicialização", ShowStartup);
        AddNav(nav, "◎   Rede", ShowNetwork);
        AddNav(nav, "▣   Processos", ShowProcesses);
        AddNav(nav, "ϟ   Energia", ShowPower);
        AddNav(nav, "▦   Aplicativos", ShowApps);
        AddNav(nav, "⚙   Ferramentas", ShowTools);
        var main = new Panel { Dock = DockStyle.Fill, Padding = new Padding(0) }; shell.Controls.Add(main);
        var top = new Panel { Dock = DockStyle.Top, Height = 72, Padding = new Padding(25, 18, 25, 10), BackColor = bg }; main.Controls.Add(top);
        pageTitle.Dock = DockStyle.Left; top.Controls.Add(pageTitle); status.Dock = DockStyle.Right; status.Text = "PRONTO  •  MODO SEGURO"; top.Controls.Add(status);
        main.Controls.Add(content); content.BringToFront(); ShowDashboard();
    }

    private void AddNav(Control parent, string text, Action action)
    {
        var b = new Button { Text = text, Width = 190, Height = 44, FlatStyle = FlatStyle.Flat, TextAlign = ContentAlignment.MiddleLeft, BackColor = Color.FromArgb(17, 23, 37), ForeColor = Color.FromArgb(205, 215, 235), Font = new Font("Segoe UI", 10, FontStyle.Semibold), Margin = new Padding(0, 3, 0, 3), Cursor = Cursors.Hand };
        b.FlatAppearance.BorderSize = 0; b.FlatAppearance.MouseOverBackColor = Color.FromArgb(35, 47, 72); b.Click += (_, _) => action(); parent.Controls.Add(b);
    }
    private void BeginPage(string title)
    {
        pageTitle.Text = title; content.Controls.Clear(); content.SuspendLayout();
    }
    private void EndPage() => content.ResumeLayout();
    private Label Heading(string text) => new() { Text = text, AutoSize = true, ForeColor = Color.White, Font = new Font("Segoe UI", 13, FontStyle.Bold), Margin = new Padding(0, 15, 0, 10) };
    private Panel Card(string title, string value, string detail)
    {
        var p = new Panel { Width = 245, Height = 125, BackColor = panel, Margin = new Padding(0, 0, 14, 14), Padding = new Padding(16) };
        p.Controls.Add(new Label { Text = title.ToUpperInvariant(), AutoSize = true, ForeColor = Color.FromArgb(145, 163, 194), Font = new Font("Segoe UI", 9, FontStyle.Bold), Location = new Point(15, 13) });
        p.Controls.Add(new Label { Text = value, AutoSize = true, ForeColor = Color.White, Font = new Font("Segoe UI", 20, FontStyle.Bold), Location = new Point(15, 38) });
        p.Controls.Add(new Label { Text = detail, AutoSize = true, ForeColor = Color.FromArgb(145, 163, 194), Font = new Font("Segoe UI", 8), Location = new Point(16, 86) }); return p;
    }
    private void ShowDashboard()
    {
        BeginPage("Visão geral");
        content.Controls.Add(new Label { Text = "Seu computador, em um só lugar.", AutoSize = true, ForeColor = Color.FromArgb(160, 177, 205), Font = new Font("Segoe UI", 11), Margin = new Padding(0, 0, 0, 22) });
        var flow = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 155, AutoSize = false, WrapContents = true, BackColor = bg };
        var mem = GetMemory(); var drive = DriveInfo.GetDrives().FirstOrDefault(d => d.IsReady && d.Name.StartsWith(Path.GetPathRoot(Environment.SystemDirectory)!, StringComparison.OrdinalIgnoreCase));
        flow.Controls.Add(Card("Sistema", Environment.OSVersion.Version.ToString(), Environment.OSVersion.Platform.ToString()));
        flow.Controls.Add(Card("Memória RAM", mem.Total > 0 ? $"{mem.Used:0.0}/{mem.Total:0.0} GB" : "Indisponível", "Em uso / total"));
        flow.Controls.Add(Card("Armazenamento", drive != null ? $"{(drive.TotalSize-drive.AvailableFreeSpace)/1e9:0} GB" : "N/D", drive != null ? $"Livre: {drive.AvailableFreeSpace/1e9:0} GB" : "Disco do sistema"));
        flow.Controls.Add(Card("Arquitetura", Environment.Is64BitOperatingSystem ? "64 bits" : "32 bits", Environment.MachineName)); content.Controls.Add(flow);
        content.Controls.Add(Heading("Ações rápidas"));
        var actions = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 65, AutoSize = false, BackColor = bg };
        actions.Controls.Add(ActionButton("Analisar arquivos temporários", ShowCleaner)); actions.Controls.Add(ActionButton("Ver programas de inicialização", ShowStartup)); actions.Controls.Add(ActionButton("Diagnóstico de rede", ShowNetwork)); content.Controls.Add(actions);
        content.Controls.Add(Heading("Princípios do Nexus"));
        content.Controls.Add(new Label { Text = "• Nenhuma alteração escondida.  • Prévia antes de excluir.  • Sem desativar o Windows Defender ou o Windows Update.\n• O aplicativo não promete FPS mágico: otimizações dependem do hardware e do uso.", AutoSize = true, ForeColor = Color.FromArgb(170, 184, 208), MaximumSize = new Size(850, 0) }); EndPage();
    }
    private Button ActionButton(string text, Action a) { var b = new Button { Text = text, AutoSize = true, Height = 42, FlatStyle = FlatStyle.Flat, BackColor = panel, ForeColor = Color.White, Padding = new Padding(12, 4, 12, 4), Margin = new Padding(0, 0, 10, 0) }; b.FlatAppearance.BorderColor = Color.FromArgb(53, 69, 101); b.Click += (_, _) => a(); return b; }
    private (double Used, double Total) GetMemory() { var m = new MEMORYSTATUSEX(); return GlobalMemoryStatusEx(m) ? ((m.ullTotalPhys-m.ullAvailPhys)/1073741824d, m.ullTotalPhys/1073741824d) : (0,0); }

    private void ShowPerformance()
    {
        BeginPage("Desempenho e hardware");
        var cpu = Registry.GetValue(@"HKEY_LOCAL_MACHINE\HARDWARE\DESCRIPTION\System\CentralProcessor\0", "ProcessorNameString", "Não identificado")?.ToString() ?? "Não identificado";
        var m = GetMemory(); var sb = new StringBuilder(); sb.AppendLine("RESUMO DO SISTEMA").AppendLine(new string('─', 55)).AppendLine($"Processador: {cpu}").AppendLine($"Memória: {m.Used:0.00} GB em uso de {m.Total:0.00} GB").AppendLine($"Windows: {Environment.OSVersion}").AppendLine($"Arquitetura do processo: {(Environment.Is64BitProcess ? "64" : "32")} bits").AppendLine($"Nome do PC: {Environment.MachineName}").AppendLine().AppendLine("UNIDADES");
        foreach (var d in DriveInfo.GetDrives().Where(x => x.IsReady)) sb.AppendLine($"{d.Name}  |  {d.DriveFormat}  |  livre {d.AvailableFreeSpace/1e9:0.0} GB / {d.TotalSize/1e9:0.0} GB");
        AddOutput(sb.ToString()); EndPage();
    }
    private void ShowCleaner()
    {
        BeginPage("Limpeza segura");
        content.Controls.Add(new Label { Text = "O Nexus apenas lista arquivos temporários do seu perfil. Revise a lista antes de excluir. Arquivos em uso serão ignorados.", AutoSize = true, ForeColor = Color.FromArgb(165,180,205), MaximumSize = new Size(850,0) });
        var list = new ListBox { Dock = DockStyle.Top, Height = 340, BackColor = Color.FromArgb(15,21,34), ForeColor = Color.Gainsboro, BorderStyle = BorderStyle.None, SelectionMode = SelectionMode.MultiExtended, Font = new Font("Consolas", 9) };
        var files = new List<string>();
        var scan = ActionButton("Analisar", () => { files.Clear(); list.Items.Clear(); var root = Path.GetTempPath(); try { foreach (var f in Directory.EnumerateFiles(root, "*", SearchOption.AllDirectories)) { try { var fi = new FileInfo(f); if (!fi.Attributes.HasFlag(FileAttributes.ReparsePoint)) files.Add(f); } catch { } } } catch { } foreach (var f in files.Take(5000)) list.Items.Add(f); status.Text = $"ANÁLISE: {files.Count} ARQUIVOS"; });
        var clean = ActionButton("Excluir selecionados", () => { if (list.SelectedItems.Count == 0) { MessageBox.Show("Selecione os arquivos que deseja excluir."); return; } if (MessageBox.Show($"Excluir {list.SelectedItems.Count} arquivo(s) selecionado(s)? Esta ação não pode ser desfeita.", "Confirmar limpeza", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return; int n=0; foreach (var item in list.SelectedItems.Cast<string>().ToArray()) { try { File.Delete(item); files.Remove(item); list.Items.Remove(item); n++; } catch { } } MessageBox.Show($"Arquivos removidos: {n}. Arquivos em uso ou protegidos foram ignorados."); });
        var row = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 55, BackColor = bg }; row.Controls.Add(scan); row.Controls.Add(clean); content.Controls.Add(row); content.Controls.Add(list); EndPage();
    }
    private void ShowStartup()
    {
        BeginPage("Inicialização");
        content.Controls.Add(new Label { Text = "Visualização dos atalhos e entradas de inicialização. Esta primeira versão não altera nem remove entradas automaticamente.", AutoSize = true, ForeColor = Color.FromArgb(165,180,205), MaximumSize = new Size(850,0) });
        var sb = new StringBuilder(); string[] keys = { @"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", @"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Run" };
        foreach (var hive in new[] { Registry.CurrentUser, Registry.LocalMachine }) foreach (var key in keys) { try { using var k = hive.OpenSubKey(key); if (k == null) continue; foreach (var name in k.GetValueNames()) sb.AppendLine($"{hive.Name}\{key}\{name}\n  {k.GetValue(name)}\n"); } catch { } }
        foreach (var folder in new[] { Environment.GetFolderPath(Environment.SpecialFolder.Startup), Environment.GetFolderPath(Environment.SpecialFolder.CommonStartup) }) { sb.AppendLine($"PASTA: {folder}"); try { foreach (var f in Directory.GetFiles(folder)) sb.AppendLine("  "+f); } catch { } }
        AddOutput(sb.ToString()); EndPage();
    }
    private void ShowNetwork()
    {
        BeginPage("Rede"); var sb = new StringBuilder("ADAPTADORES DE REDE\n────────────────────────────────────────\n");
        foreach (var n in NetworkInterface.GetAllNetworkInterfaces()) { sb.AppendLine($"{n.Name} — {n.NetworkInterfaceType} — {n.OperationalStatus}"); foreach (var a in n.GetIPProperties().UnicastAddresses) sb.AppendLine("  "+a.Address); sb.AppendLine(); }
        var row = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 55, BackColor = bg }; row.Controls.Add(ActionButton("Executar ping 1.1.1.1", async () => { try { using var p = new Ping(); var r = await p.SendPingAsync("1.1.1.1", 2500); MessageBox.Show($"Status: {r.Status}\nTempo: {r.RoundtripTime} ms"); } catch (Exception ex) { MessageBox.Show(ex.Message); } }));
        row.Controls.Add(ActionButton("Limpar cache DNS", () => { if (MessageBox.Show("Executar ipconfig /flushdns?", "Confirmar", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return; try { var p = Process.Start(new ProcessStartInfo("ipconfig", "/flushdns") { UseShellExecute=false, CreateNoWindow=true, RedirectStandardOutput=true }); string text = p?.StandardOutput.ReadToEnd() ?? "Comando iniciado."; p?.WaitForExit(5000); MessageBox.Show(text); } catch (Exception ex) { MessageBox.Show(ex.Message); } })); content.Controls.Add(row); AddOutput(sb.ToString()); EndPage();
    }

    private void ShowProcesses()
    {
        BeginPage("Gerenciador de processos");
        content.Controls.Add(new Label { Text = "Veja os processos em execução. Encerrar um processo pode fazer você perder dados não salvos; confirme cada ação.", AutoSize = true, ForeColor = Color.FromArgb(165,180,205), MaximumSize = new Size(850,0) });
        var list = new ListView { Dock = DockStyle.Top, Height = 430, View = View.Details, FullRowSelect = true, BackColor = Color.FromArgb(15,21,34), ForeColor = Color.Gainsboro, BorderStyle = BorderStyle.None };
        list.Columns.Add("Processo", 250); list.Columns.Add("PID", 90); list.Columns.Add("Memória (MB)", 130);
        void RefreshList()
        {
            list.Items.Clear();
            foreach (var p in Process.GetProcesses().OrderBy(x => x.ProcessName).Take(1500))
            {
                try { var item = new ListViewItem(p.ProcessName); item.SubItems.Add(p.Id.ToString()); item.SubItems.Add((p.WorkingSet64 / 1048576d).ToString("0.0")); list.Items.Add(item); }
                catch { }
                finally { p.Dispose(); }
            }
            status.Text = $"PROCESSOS: {list.Items.Count}";
        }
        var row = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 55, BackColor = bg };
        row.Controls.Add(ActionButton("Atualizar lista", RefreshList));
        row.Controls.Add(ActionButton("Encerrar selecionado", () => {
            if (list.SelectedItems.Count == 0) { MessageBox.Show("Selecione um processo."); return; }
            var item = list.SelectedItems[0]; var name = item.Text; if (!int.TryParse(item.SubItems[1].Text, out var pid)) return;
            if (MessageBox.Show($"Deseja tentar encerrar {name} (PID {pid})? Dados não salvos podem ser perdidos.", "Confirmar", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
            try { using var p = Process.GetProcessById(pid); p.Kill(); MessageBox.Show("Solicitação de encerramento enviada."); RefreshList(); } catch (Exception ex) { MessageBox.Show("Não foi possível encerrar: " + ex.Message); }
        }));
        content.Controls.Add(row); content.Controls.Add(list); RefreshList(); EndPage();
    }
    private void ShowPower()
    {
        BeginPage("Planos de energia");
        content.Controls.Add(new Label { Text = "Consulte os planos de energia do Windows e selecione um plano existente. O Windows pode limitar as opções conforme o hardware.", AutoSize = true, ForeColor = Color.FromArgb(165,180,205), MaximumSize = new Size(850,0) });
        var list = new ListBox { Dock = DockStyle.Top, Height = 250, BackColor = Color.FromArgb(15,21,34), ForeColor = Color.Gainsboro, BorderStyle = BorderStyle.None, Font = new Font("Consolas", 10) };
        var ids = new List<string>();
        var row = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 55, BackColor = bg };
        row.Controls.Add(ActionButton("Atualizar planos", () => {
            list.Items.Clear(); ids.Clear();
            try { using var p = Process.Start(new ProcessStartInfo("powercfg", "/list") { UseShellExecute=false, CreateNoWindow=true, RedirectStandardOutput=true, RedirectStandardError=true }); var text = p?.StandardOutput.ReadToEnd() ?? ""; p?.WaitForExit(5000);
                foreach (var line in text.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries)) { var m = System.Text.RegularExpressions.Regex.Match(line, @"([0-9a-fA-F-]{36})"); if (m.Success) { ids.Add(m.Groups[1].Value); list.Items.Add(line.Trim()); } }
                if (ids.Count == 0) list.Items.Add("Nenhum plano encontrado. " + text.Trim());
            } catch (Exception ex) { MessageBox.Show(ex.Message); }
        }));
        row.Controls.Add(ActionButton("Ativar plano selecionado", () => {
            if (list.SelectedIndex < 0 || list.SelectedIndex >= ids.Count) { MessageBox.Show("Selecione um plano válido."); return; }
            if (MessageBox.Show("Ativar este plano de energia do Windows?", "Confirmar", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            try { using var p = Process.Start(new ProcessStartInfo("powercfg", "/setactive " + ids[list.SelectedIndex]) { UseShellExecute=false, CreateNoWindow=true, RedirectStandardOutput=true, RedirectStandardError=true }); p?.WaitForExit(5000); MessageBox.Show(p?.ExitCode == 0 ? "Plano ativado." : "O Windows não permitiu ativar o plano."); } catch (Exception ex) { MessageBox.Show(ex.Message); }
        }));
        content.Controls.Add(row); content.Controls.Add(list); EndPage();
    }
    private void ShowApps()
    {
        BeginPage("Aplicativos instalados");
        content.Controls.Add(new Label { Text = "Inventário somente para consulta dos aplicativos registrados no Windows. Esta tela não desinstala programas.", AutoSize = true, ForeColor = Color.FromArgb(165,180,205), MaximumSize = new Size(850,0) });
        var box = new ListBox { Dock = DockStyle.Fill, BackColor = Color.FromArgb(15,21,34), ForeColor = Color.Gainsboro, BorderStyle = BorderStyle.None, Font = new Font("Segoe UI", 9) };
        var names = new SortedSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var hive in new[] { Registry.LocalMachine, Registry.CurrentUser })
        foreach (var path in new[] { @"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall", @"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall" })
        {
            try { using var root = hive.OpenSubKey(path); if (root == null) continue; foreach (var sub in root.GetSubKeyNames()) { try { using var k = root.OpenSubKey(sub); var n = k?.GetValue("DisplayName")?.ToString(); if (!string.IsNullOrWhiteSpace(n)) names.Add(n); } catch { } } } catch { }
        }
        foreach (var n in names) box.Items.Add(n);
        status.Text = $"APLICATIVOS: {names.Count}"; content.Controls.Add(box); EndPage();
    }

    private void ShowTools()
    {
        BeginPage("Ferramentas");
        content.Controls.Add(Heading("Ferramentas disponíveis"));
        content.Controls.Add(new Label { Text = "• Informações do Windows e hardware\n• Análise de armazenamento\n• Inventário de inicialização\n• Diagnóstico de adaptadores de rede\n• Teste de conectividade\n• Limpeza DNS com confirmação\n• Gerenciador de processos com confirmação\n• Consulta e ativação de planos de energia\n• Inventário de aplicativos instalados\n\nPróximos módulos planejados: perfis de energia, análise de processos, pontos de restauração, monitor de uso em tempo real, gerenciador de aplicativos e catálogo de ajustes com reversão.", AutoSize = true, ForeColor = Color.FromArgb(175,190,214), MaximumSize = new Size(850,0) });
        content.Controls.Add(Heading("Segurança")); content.Controls.Add(new Label { Text = "O Nexus não desativa antivírus, firewall, atualizações ou mecanismos de segurança. Não execute ajustes encontrados na internet sem entender seus efeitos.", AutoSize = true, ForeColor = Color.FromArgb(235,190,120), MaximumSize = new Size(850,0) }); EndPage();
    }
    private void AddOutput(string text)
    {
        var box = new Panel { Dock = DockStyle.Fill, BackColor = Color.FromArgb(15,21,34), Padding = new Padding(12) }; output.Text = text; box.Controls.Add(output); content.Controls.Add(box);
    }
}
