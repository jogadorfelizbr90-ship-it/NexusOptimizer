@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0src"
echo ==========================================
echo          NEXUS OPTIMIZER - BUILD
echo ==========================================
where dotnet >nul 2>nul
if errorlevel 1 (
  echo .NET 8 SDK nao encontrado neste PC.
  echo Para nao instalar nada localmente, use o workflow de compilacao na nuvem descrito no README.txt.
  pause
  exit /b 1
)
dotnet publish NexusOptimizer.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -p:EnableCompressionInSingleFile=true -o "%~dp0dist"
if errorlevel 1 (
  echo.
  echo Falha na compilacao. Verifique o SDK .NET 8 e a conexao para restaurar pacotes.
  pause
  exit /b 1
)
echo.
echo CONCLUIDO: %~dp0dist\NexusOptimizer.exe
pause
