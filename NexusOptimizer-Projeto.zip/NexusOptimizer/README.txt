NEXUS OPTIMIZER — aplicativo próprio para Windows

O QUE É
Projeto C# / Windows Forms / .NET 8. O código do NEXUS é independente e NÃO usa, executa, incorpora nem modifica Optimizer-17.1.exe.

MÓDULOS NO CÓDIGO
- Visão geral: versão do Windows, arquitetura, RAM e armazenamento.
- Desempenho: identificação do processador, memória e unidades.
- Limpeza segura: analisa arquivos temporários do perfil e permite excluir itens selecionados após confirmação.
- Inicialização: consulta entradas comuns do Registro e pastas de inicialização (somente leitura).
- Rede: lista adaptadores/IP, testa conectividade e oferece limpeza do cache DNS com confirmação.
- Processos: lista processos e permite solicitar encerramento individual com confirmação.
- Energia: lista planos de energia e permite ativar um plano selecionado.
- Aplicativos: inventário de programas registrados (somente leitura).

SEGURANÇA
- Não desativa Windows Defender, firewall ou Windows Update.
- Não aplica alterações ocultas no Registro.
- Ações potencialmente disruptivas pedem confirmação.
- Encerrar processos pode causar perda de dados não salvos.

COMO GERAR O EXE
O projeto já contém duas formas automatizadas de compilação:

A) Compilação local em Windows:
   Execute COMPILAR.bat em um PC com .NET 8 SDK instalado.
   Saída: dist\NexusOptimizer.exe

B) Compilação na nuvem (sem instalar SDK no PC):
   O arquivo .github/workflows/windows-build.yml configura uma compilação no Windows hospedado pelo GitHub Actions.
   Depois de colocar este projeto em um repositório GitHub, abra a aba Actions e execute "Build NEXUS OPTIMIZER for Windows". Baixe o artefato "NexusOptimizer-Windows-x64" da execução concluída. O artefato contém NexusOptimizer.exe.

CONFIGURAÇÃO DE PUBLICAÇÃO
A publicação usa win-x64, Release, self-contained e PublishSingleFile. Isso gera um executável Windows 64-bit com o runtime .NET incluído. O arquivo será maior que um executável dependente do runtime.

LIMITAÇÃO DESTA SESSÃO
Este ambiente não tem .NET SDK nem toolchain de Windows, e não tem acesso de rede para baixar um compilador. Por isso não foi possível executar a compilação nem validar um .exe real nesta sessão. Não apresento um arquivo renomeado ou fictício como se fosse o programa compilado.
